?php 

$cant_churro = $_POST["cant_churro"];
$valor_churro = "1500";
if ($cant_churro < 0)
$vfinal_churro = $cant_churro*$valor_churro;



echo "el valor total a pagar de sus churros es de:".$vfinal_churro;



?>