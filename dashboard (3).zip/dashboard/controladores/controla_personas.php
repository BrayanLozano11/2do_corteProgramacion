<?php 

$nombres = $_POST["Nombre"];
$documento = $_POST["documento"];
$fecha_nacimiento = $_POST["fecha_nacimiento"];
$celular = $_POST["celular"];

echo "el celular es:".$celular;



?>