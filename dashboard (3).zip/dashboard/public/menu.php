<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="VENDER.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                VENDER
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="ORDEN Y DESORDEN.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                ORDEN Y DESORDEN
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="PRODUCTOS AL MAYOR.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                PRODUCTOS AL MAYOR
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href=" PEDIDOS A DOMICILIO.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                PEDIDOS A DOMICILIO
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="REPORTES O NOTICIAS.php">
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                REPORTES O NOTICIAS 
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href=" FACTURAS O PAGOS.php">
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                FACTURAS O PAGOS
              </a>
            </li>
</ul>